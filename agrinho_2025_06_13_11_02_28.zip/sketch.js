let x = 50;
let y = 300;
let questionActive = false;
let currentQuestion = 0;
let showWin = false;

let questions = [
  {
    q: "O que representa a conexão entre o campo e a cidade no nosso dia a dia?",
    options: ["O trânsito urbano", "A troca de mensagens por celular", "O transporte de alimentos e produtos agrícolas"],
    correct: 2
  },
  {
    q: "Qual é uma das principais contribuições do campo para a vida nas cidades?",
    options: ["Produção de softwares", "Produção de alimentos como leite, arroz e frutas", "Construção de edifícios"],
    correct: 1
  },
  {
    q: "Como a cidade contribui para o desenvolvimento do campo?",
    options: ["Fornecendo clima favorável", "Fornecendo tecnologia, máquinas e apoio técnico", "Aumentando a distância entre os dois"],
    correct: 1
  },
  {
    q: "Por que é importante valorizar os produtores rurais?",
    options: ["Porque eles vivem longe da cidade", "Porque cultivam a terra e produzem alimentos para todos", "Porque usam roupas diferentes"],
    correct: 1
  },
  {
    q: "O que seria difícil de encontrar nas cidades sem o trabalho do campo?",
    options: ["Praças e parques", "Frutas, legumes e carnes", "Prédios e ruas"],
    correct: 1
  }
];

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(16);
}

function draw() {
  background(200, 255, 200);

  // Estrada
  fill(100);
  rect(0, 350, width, 50);

  drawScenario();

  // Trator
  if (!questionActive && !showWin) {
    x += 1;
  }
  drawTractor(x, y);

  // Verifica fim do jogo
  if (x >= width - 100 && !questionActive) {
    showWin = true;
  }

  // Exibe perguntas em pontos definidos (5 perguntas)
  if ((x === 150 || x === 275 || x === 400 || x === 525 || x === 650) && currentQuestion < questions.length) {
    questionActive = true;
  }

  if (questionActive) {
    drawQuestion(questions[currentQuestion]);
  }

  // Mostrar mensagem final sem pontuação
  if (showWin) {
    fill(0, 200, 0);
    textSize(24);
    text("Você chegou ao mercado! 🌽🏙️", width / 2, height / 2);
  }
}

function drawScenario() {
  // Fazenda
  fill(255, 200, 0);
  rect(50, 250, 80, 80);
  fill(0);
  text("Fazenda", 90, 340);

  // Mercado
  fill(200, 100, 100);
  rect(width - 150, 250, 80, 80);
  fill(0);
  text("Mercado", width - 110, 340);
}

function drawTractor(x, y) {
  fill(255, 0, 0);
  rect(x, y, 50, 30);
  fill(0);
  ellipse(x + 10, y + 30, 20);
  ellipse(x + 40, y + 30, 20);
}

function drawQuestion(q) {
  fill(255);
  rect(100, 50, width - 200, 200, 10);
  fill(0);
  textSize(16);
  text(q.q, width / 2, 80);

  for (let i = 0; i < q.options.length; i++) {
    fill(200);
    rect(150, 120 + i * 40, 500, 30);
    fill(0);
    text(q.options[i], 400, 135 + i * 40);
  }
}

function mousePressed() {
  if (!questionActive) return;

  for (let i = 0; i < 3; i++) {
    if (mouseX > 150 && mouseX < 650 && mouseY > 120 + i * 40 && mouseY < 150 + i * 40) {
      if (i === questions[currentQuestion].correct) {
        currentQuestion++;
        questionActive = false;
      } else {
        x -= 30; // Penalidade
        questionActive = false;
      }
    }
  }
}